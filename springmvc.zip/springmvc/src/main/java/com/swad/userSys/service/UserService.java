package com.swad.userSys.service;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
public interface UserService {
}
