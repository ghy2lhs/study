package com.swad.userSys.serviceImpl;

import com.swad.userSys.service.UserService;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
public class UserServiceImpl   implements UserService{

}
