package com.swad.userSys.web.query.model;

import com.google.gson.JsonObject;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
public class UserQuery {


    private String name;
    private String telephone;
    private String address;

    public static void main(String [] args){
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("query","test");
        System.out.println(jsonObject.toString());
    }


    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
