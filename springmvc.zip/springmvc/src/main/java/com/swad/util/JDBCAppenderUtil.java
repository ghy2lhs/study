package com.swad.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;
import org.apache.log4j.jdbc.JDBCAppender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class JDBCAppenderUtil extends JDBCAppender {
	
	protected Connection connection;
	
	private static Logger LOG = LoggerFactory.getLogger(JDBCAppenderUtil.class);
	
	private static int count = 0;
	
	private static DataSource source = null;
			
	public JDBCAppenderUtil() {
		super();
		initDataSource();
	}
	
	
	private static void initDataSource() {
		//使用配置文件链接
		Properties p = new Properties();
		InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream("init_database.properties");
		try {
			p.load(stream);
			source = BasicDataSourceFactory.createDataSource(p);
		} catch (Exception e) {
			LOG.debug("初始化database异常：", e);
		}
	}
	
	
	protected void closeConnection(Connection con) {
		try {
			if (connection != null && !connection.isClosed()) {
				connection.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	protected Connection getConnection() throws SQLException{
		
		try {
			if (source==null) {
				initDataSource();
			}
			connection = source.getConnection();
		} catch (Exception e) {
			if (source==null) {
				initDataSource();
			}
			connection = source.getConnection();
			return connection;
		}
		return connection;
	}
	
}
