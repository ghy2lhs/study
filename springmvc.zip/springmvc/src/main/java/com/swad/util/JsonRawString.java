/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.swad.util;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;


@JsonSerialize(using = RawStringSerializer.class)
public class JsonRawString {
    private String content = null;

    public JsonRawString(String content) {
        this.content = content;
    }
    
    public String asString() {
        return this.content;
    }

	@Override
	public String toString() {
		return content ;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
