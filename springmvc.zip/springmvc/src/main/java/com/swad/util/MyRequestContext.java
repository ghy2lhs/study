package com.swad.util;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;



/**
 * 监听每次请求，获取包装了请求的类
 * 
 * @author zhaoyehong
 */
@Component
public class MyRequestContext {
	
	/**默认session过期时间*/
	public static Integer SESSION_EXPIRE_TIME = 60 * 20;
	
/*	 @Autowired
	 private ISystemBaseService systemBaseService;*/

	 private static MyRequestContext myRequestContext;
	
	/**
	 * 获取当前请求中的session
	 * @return HttpSession对象
	 */
	public static HttpSession getSessionContext(){
		ServletRequestAttributes requestAttributes = (ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
		HttpSession session = requestAttributes.getRequest().getSession();
/*		Authconfig authConfig = myRequestContext.systemBaseService.getAuthConfig();
		//设置超时时间为:数据库中配置的时间
		if (authConfig == null || authConfig.getSession_maxtime() == null || authConfig.getSession_maxtime() == 0) {
			session.setMaxInactiveInterval(SESSION_EXPIRE_TIME);
		}else {
			session.setMaxInactiveInterval(authConfig.getSession_maxtime() * 60);
		}*/
		
		return session;
	}
	
	
    @PostConstruct
    public void init(){
    	myRequestContext = this;
    	//myRequestContext.systemBaseService = this.systemBaseService;
    }
    
    
	/**
	 * 获取当前请求中的request
	 * @return request对象
	 */
	public static HttpServletRequest getRequestContext(){
		return ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
	}
	
	/**
	 * 获取响应对象response
	 * @return response对象
	 */
	public static HttpServletResponse getResponseContext(){
		return ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getResponse();
	}
}
