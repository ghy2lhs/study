package com.swad.util;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.userdetails.User;
import org.springframework.util.StringUtils;


/**
 * 用户上下文对象
 * 
 * @author zhaoyehong
 */
public class UserContext {
	
	public static final String USER_IN_SESSION = "user_in_session";
	public static final String HTTP_ACCEPT_LANGUAGE_ENGLISH         = "en";
	//放入session中
	public static void setUser(User user){
		MyRequestContext.getSessionContext().setAttribute(USER_IN_SESSION, user);
	}
	
	//获取用户
	public static User getUser(){
		return (User)MyRequestContext.getSessionContext().getAttribute(USER_IN_SESSION);
	}
	
	//获取请求地址主机的真实IP
	public static String getRemoteAddr(){
		HttpServletRequest request = MyRequestContext.getRequestContext();
		String ip = request.getHeader("X-Real-IP");
        if (!StringUtils.isEmpty(ip) && !"unknown".equalsIgnoreCase(ip)) {
            return ip;  
        }  
        ip = request.getHeader("X-Forwarded-For");  
        if (!StringUtils.isEmpty(ip) && !"unknown".equalsIgnoreCase(ip)) {
            // 多次反向代理后会有多个IP值，第一个为真实IP。  
            int index = ip.indexOf(',');  
            if (index != -1) {  
                return ip.substring(0, index);  
            } else {  
                return ip;  
            }  
        } else {  
            return request.getRemoteAddr();  
        }  
	}
	/**
	 * if the request's languague is english then return true , else return false
	 * @return boolean 
	 */
	public static boolean getRemoteLanguague(){
		HttpServletRequest request = MyRequestContext.getRequestContext();
		if(request.getLocale().getLanguage().equals(HTTP_ACCEPT_LANGUAGE_ENGLISH)){
			return true;
		}
		return false;
	}
	//注销用户
	public static void logout() {
		MyRequestContext.getSessionContext().removeAttribute(USER_IN_SESSION);
	}
}
