package com.swad.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileUtil {

	public static void writeFileString(String fileName, String content){
		File f = new File(fileName);
		try {
			FileWriter fw = new FileWriter(f);
			fw.write(content);
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 *  获取模板文件的路径  WebRoot/
	 * @return
	 */
	public String getWebClassesPath() {
		String path=this.getClass().getClassLoader().getResource("").getPath()+File.separator;
		return path;
	}
	
}
