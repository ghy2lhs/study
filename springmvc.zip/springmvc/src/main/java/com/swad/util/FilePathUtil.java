package com.swad.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 用于封装上传下载文件路径
 * Created by wuke on 2016/12/7.
 */
public class FilePathUtil {
    /**
     * 拼接文件路径
     * 格式为：基本路径+一年的第几周+session+后缀(.zip.xsl)
     * @param sessionId sessionId
     * @param fileTempDir 基本路径
     * @param suffix 后缀(.zip.xsl)
     * @return 拼好的路径
     */
    public static String contractFilePath(String sessionId, String fileTempDir,String suffix) {
        Calendar cal=Calendar.getInstance();
        cal.setTime(new Date());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String fileDir=fileTempDir+sdf.format(cal.getTime())+ File.separator;
        File f=new File(fileDir);
        if(!f.exists()){
            f.mkdirs();
        }
        return fileDir+sessionId+suffix;
    }
}
