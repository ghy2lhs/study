package com.swad.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;

import java.security.NoSuchAlgorithmException;


public class MD5Util {
    private final static Logger LOGGER = LoggerFactory.getLogger(MD5Util.class);
	   public static void md5() {
	        Md5PasswordEncoder md5 = new Md5PasswordEncoder();
	        // false 表示：生成32位的Hex版, 这也是encodeHashAsBase64的, Acegi 默认配置; true  表示：生成24位的Base64版     
	        md5.setEncodeHashAsBase64(false);     
	        String pwd = md5.encodePassword("1234", null);     
	        LOGGER.debug("MD5: {} len={}", pwd, pwd.length());     
	    }  
	   
       
	    public static String md5_SystemWideSaltSource (String password,String salt) {     
	        Md5PasswordEncoder md5 = new Md5PasswordEncoder();     
	        md5.setEncodeHashAsBase64(false);     
	        // 使用动态加密盐的只需要在注册用户的时候将第二个参数换成用户名即可     
	        return md5.encodePassword(password, salt);     
	    }     
	    
	    public static void sha_256() throws NoSuchAlgorithmException {       
	        ShaPasswordEncoder sha = new ShaPasswordEncoder(256);
	        sha.setEncodeHashAsBase64(true);     
	        String pwd = sha.encodePassword("1234", null);     
	        LOGGER.debug("哈希算法 256: {} len={}",  pwd, pwd.length());     
	    }     
	         
	        
	    public static void sha_SHA_256() {     
	        ShaPasswordEncoder sha = new ShaPasswordEncoder();     
	        sha.setEncodeHashAsBase64(false);     
	        String pwd = sha.encodePassword("1234", null);      
	        LOGGER.debug("哈希算法 SHA-256: {} len={}", pwd, pwd.length());     
	    }     
	         
	
}
