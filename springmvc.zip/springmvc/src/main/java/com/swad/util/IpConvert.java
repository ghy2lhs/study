package com.swad.util;

/**
 * Created by gonghaiyu on 2017/4/19.
 */
public class IpConvert {
    /**
     * IPv4地址转换成长整数形式
     *
     * @param ip IPv4地址
     * @return IPv4整数表示
     */
    public static long ipv42long(String ip) {
        long ret = -1;

        String[] fragments = ip.split("\\.", 4);

        try {
            long f1 = Long.parseLong(fragments[0]);
            long f2 = Long.parseLong(fragments[1]);
            long f3 = Long.parseLong(fragments[2]);
            long f4 = Long.parseLong(fragments[3]);
            ret = (f1 << 24) + (f2 << 16) + (f3 << 8) + f4;
        } catch(NumberFormatException ex) {
            ex.printStackTrace();
        }
        return ret;
    }
}
