package com.swad.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class DatabaseInitUtil {
    private static Logger LOGGER = LoggerFactory
            .getLogger(DatabaseInitUtil.class);
    private static Connection connection = null;

    @Value("${mysql.driver}")
    private String driver;

    @Value("${mysql.url}")
    private String url;

    @Value("${mysql.initurl}")
    private String initurl;


    @Value("${mysql.username}")
    private String username;

    @Value("${mysql.password}")
    private String password;

    /**
     * 初始化数据库
     *
     * @throws
     */
    public void initDataBase() throws IOException {
        try {
            Class.forName(driver).newInstance();
            connection = DriverManager.getConnection(initurl, username, password);
            Statement state = connection.createStatement();

            //创建存储过程SQL语句
            String createProcedure = file2String("cybervision.sql", "UTF-8");

            //创建存储过程
            state.executeUpdate("USE cybervision;");
            state.executeUpdate("drop procedure IF EXISTS initCybervision;");
            state.executeUpdate(createProcedure);

            //调用存储过程
            CallableStatement cs = connection.prepareCall("{call initCybervision}");//创建一个 CallableStatement 对象来调用数据库存储过程
            //返回调用的结果集
            cs.executeQuery();

            connection.close();
            state.close();

        } catch (Exception e) {
            LOGGER.error("数据库初始化失败：" + e.getMessage());
        } finally {
        }

    }


    /**
     * 文本文件转换为指定编码的字符串
     *
     * @param fileName 文本文件
     * @param encoding 编码类型
     * @return 转换后的字符串
     * @throws IOException
     */
    public static String file2String(String fileName, String encoding) {
        InputStreamReader reader = null;

        InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);

        StringWriter writer = new StringWriter();
        try {
            reader = new InputStreamReader(stream, encoding);
            //将输入流写入输出流
            char[] buffer = new char[1024];
            int n = 0;
            while (-1 != (n = reader.read(buffer))) {
                writer.write(buffer, 0, n);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (reader != null)
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        //返回转换结果
        if (writer != null)
            return writer.toString();
        else return null;
    }
}