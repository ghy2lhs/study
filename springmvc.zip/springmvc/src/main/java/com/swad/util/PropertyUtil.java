package com.swad.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyUtil {
	private static Properties p ;
	public static void init(){
		p = new Properties();
		InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream("project.properties");
		try {
			p.load(stream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static Properties getInstance(){
		return p;
	}
	
}
