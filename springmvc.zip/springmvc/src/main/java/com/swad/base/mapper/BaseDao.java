package com.swad.base.mapper;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
public interface BaseDao {

}
