package com.swad.base.service;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
public interface IBaseService<E, PK extends Serializable> {
    /**
     * 保存或更新一个实体
     *
     * @param entity
     * @return
     */
    E saveOrUpdate(E entity);

    /**
     * 保存一个实体
     *
     * @param entity
     * @return
     */
    E save(E entity);

    /**
     * 删除一个实体
     *
     * @param id
     */
    void delete(Serializable id);

    /**
     * 更新一个实体
     *
     * @param entity
     */
    void update(E entity);

    /**
     * 根据id查找实体
     *
     * @param id
     * @return
     */
    E getById(Serializable id);

    /**
     * 根据查询语句查找实体
     *
     * @param sql
     * @return
     */
    List<E> findBysql(String sql);

    /**
     * 查找所有的实体
     *
     * @return
     */
    List<E> findAll();

    /**
     * 根据wherehql排序
     *
     * @param entityClass
     * @param wheresql
     * @return
     */
    List<E> getPagerDesc(Class<E> entityClass, String wheresql);

    /**
     * 动态查询  根据orderby排序
     *
     * @param entityClass
     * @param likeMap
     * @param orderby
     * @return
     */
    List<E> fuzzyQuery(Class<E> entityClass, Map<String, String> likeMap, String orderby);

    /**
     * 得到数据库时间
     *
     * @return Timestamp
     */
    Timestamp getTimestamp();

    /**
     * 得到数据库时间
     *
     * @return String
     */
    String getDataAsString();

    /**
     * 得到数据库日期
     *
     * @return String
     */
    String getTimeAsString();

}
