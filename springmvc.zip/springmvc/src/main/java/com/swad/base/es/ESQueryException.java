package com.swad.base.es;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
public class ESQueryException extends Exception {
}
