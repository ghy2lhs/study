package com.swad.base.file.controller;


import com.swad.base.file.model.FileBucket;
import com.swad.base.file.model.MultiFileBucket;
import com.swad.base.file.validation.FileValidator;
import com.swad.base.file.validation.MultiFileValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by gonghaiyu on 17/04/2017.
 */
@RestController
public class FileUploadController {
    private static String UPLOAD_LOCATION = "D:\\";
    @Autowired
    FileValidator fileValidator;


    @Autowired
    MultiFileValidator multiFileValidator;


    @InitBinder("fileBucket")
    protected void initBinderFileBucket(WebDataBinder binder) {
        binder.setValidator(fileValidator);
    }


    @InitBinder("multiFileBucket")
    protected void initBinderMultiFileBucket(WebDataBinder binder) {
        binder.setValidator(multiFileValidator);
    }

    /**
     * 上传一个文件请求的界面
     * @param model
     * @return
     */
    @GetMapping(value = "/singleUpload")
    public ResponseEntity<String> getSingleUpload(ModelMap model){
        FileBucket fileModel = new FileBucket();
        model.addAttribute("fileBucket",fileModel);
        return new ResponseEntity<String>("ste", HttpStatus.OK);
    }

    /**
     * 输入url：http://127.0.0.1:8081/uploadfile
     * 选择post方式
     * 选择body
     * 选择form-data，text改为file
     * 输入key：file (为什么是file，因为FileBucket对象中存在的对象时file ，value：选择文件
     * @param fileBucket
     * @param result
     * @param model
     * @return
     * @throws IOException
     */
    @PostMapping(value = "/singleUpload")
    public ResponseEntity<String> singleFileUpload(@Valid FileBucket fileBucket, BindingResult result, ModelMap model) throws IOException{
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_PLAIN);
        if(result.hasErrors()){
            return new ResponseEntity<String>("internal_errors", HttpStatus.INTERNAL_SERVER_ERROR);
        }else{
            MultipartFile multipartFile = fileBucket.getFile();
            //Now do something with file...
            FileCopyUtils.copy(fileBucket.getFile().getBytes(), new File(UPLOAD_LOCATION + fileBucket.getFile().getOriginalFilename()));
            String fileName = multipartFile.getOriginalFilename();
            model.addAttribute("fileName", fileName);
            return new ResponseEntity<String>("upload_ok", HttpStatus.OK);
        }
    }

    /**
     * 跳转到上传多个文件界面请求的界面
     * @param model
     * @return
     */
    @RequestMapping(value="/multiUpload", method = RequestMethod.GET)
    public ResponseEntity<String> getMultiUploadPage(ModelMap model){
        MultiFileBucket filesModel = new MultiFileBucket();
        model.addAttribute("multiFileBucket",filesModel);
        return new ResponseEntity<String>("getMultiUploadpage", HttpStatus.OK);
    }

    /**
     * 同时上传三个文件
     * 请求url:http://localhost:8080/multiUpload
     * 选择post方式
     * 选择body
     * 选择form-data，text改为file
     * 输入key：files[0].file,files[1].file,files[2].file value：选择文件
     * @param multiFileBucket
     * @param result
     * @param model
     * @return
     * @throws IOException
     */
    @PostMapping(value = "/multiUpload")
    public ResponseEntity<String> multiFileUpload(@Valid MultiFileBucket multiFileBucket,
                                                  BindingResult result, ModelMap model) throws IOException{
        if(result.hasErrors()){
            return new ResponseEntity<String>("error parameter", HttpStatus.INTERNAL_SERVER_ERROR);
        }else{
            List<String> fileNames = new ArrayList<String>();
            //Now do something with file...
            for(FileBucket bucket : multiFileBucket.getFiles()){
                FileCopyUtils.copy(bucket.getFile().getBytes(), new File(UPLOAD_LOCATION + bucket.getFile().getOriginalFilename()));
                fileNames.add(bucket.getFile().getOriginalFilename());
            }
            model.addAttribute("fileNames", fileNames);
            return new ResponseEntity<String>(HttpStatus.OK);
        }
    }
}
