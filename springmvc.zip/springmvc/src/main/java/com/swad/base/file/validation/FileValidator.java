package com.swad.base.file.validation;

import com.swad.base.file.model.FileBucket;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * Created by gonghaiyu on 17/04/2017.
 */
@Component
public class FileValidator implements Validator {

    public boolean supports(Class<?> clazz) {
        return FileBucket.class.isAssignableFrom(clazz);
    }


    public void validate(Object o, Errors errors) {
        FileBucket file = (FileBucket) o;
        if(file.getFile()!=null){
            if(file.getFile().getSize() == 0 ){
                errors.rejectValue("file","missing.file");
            }
        }

    }
}
