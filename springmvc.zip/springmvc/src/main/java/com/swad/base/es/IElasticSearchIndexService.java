package com.swad.base.es;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
public interface IElasticSearchIndexService {
    /**
     * 判断索引是否存在
     * @param index_name 索引名字
     * @return   true:存在；false:不存在
     * @throws Exception
     */
    boolean isIndexExists(String index_name) throws Exception;

    /**
     * 创建索引
     * @param index_name 索引名字
     * @param type_name 类型
     * @param mapping_statement mapping语句
     * @return
     * @throws Exception
     */
    boolean createIndex(String index_name, String type_name, String mapping_statement) throws Exception;

    /**
     * 创建索引映射
     * @param index_name 索引名字
     * @param type_name  类型名字
     * @param mapping_statement  映射语句
     * @return
     * @throws Exception
     */
    boolean createIndexMapping(String index_name, String type_name, String mapping_statement)  throws Exception;

    /**
     * 得到索引映射
     * @param index_name
     * @param type_name
     * @return
     * @throws Exception
     */
    String getIndexMapping(String index_name, String type_name) throws Exception;

    /**
     * 删除索引
     * @param index_name
     * @return
     * @throws Exception
     */
    boolean deleteIndex(String index_name) throws Exception;
}
