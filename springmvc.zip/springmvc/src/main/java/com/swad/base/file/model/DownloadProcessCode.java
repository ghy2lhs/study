package com.swad.base.file.model;

/**
 * Created by wuke on 2016/12/7.
 */
public class DownloadProcessCode {
    /**
     * 导出中
     */
    public static final int DOWNLOADING=0;
    /**
     * 成功
     */
    public static final int SUCCESS=1;
    /**
     * 失败
     */
    public static final int FAILED=2;
    /**
     * 空
     */
    public static final int NULL=3;

}
