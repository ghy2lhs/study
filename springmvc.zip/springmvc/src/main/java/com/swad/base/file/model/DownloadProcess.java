package com.swad.base.file.model;

/**
 * 下载进度对象
 * Created by wuke on 2016/12/6.
 */
public class DownloadProcess {
    /**
     * 当前进度 =当前下表/总记录数
     */
    private float process;

    /**
     * 当前下标

     */
    private float index;
    /**
     * 总记录数
     */
    private int total;
    /**
     * 总数据大小kb
     */
    private int dataSize;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public Float getProcess() {
        return process;
    }

    public void setProcess(Float process) {
        this.process = process;
    }

    /**
     * 成功失败状态
    * 0下载中 1成功 2失败 3不存在
     */
    private int code;


    public int getTotal() {
        return total;
    }

    public float getIndex() {
        return index;
    }

    public void setIndex(float index) {
        this.index = index;
    }

    public void setTotal(int total) {
        this.total = total;
    }
    public int getDataSize() {
        return dataSize;
    }

    public void setDataSize(int dataSize) {
        this.dataSize = dataSize;
    }
}
