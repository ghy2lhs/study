package com.swad.base.file.controller;

import com.swad.base.file.model.DownloadProcess;
import com.swad.base.file.model.DownloadProcessCode;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.io.*;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
@RestController
public class FileDownloadController {

    private static Map<String, DownloadProcess> downloadingMap = new ConcurrentHashMap();
    ExecutorService exec = Executors.newFixedThreadPool(5);



    @GetMapping(value="/download/simple",headers = "text/html")
    public ResponseEntity<String> simpleFileDownLoad(){
        try{
            String filename = "output_report_" + new Random().nextInt(100) + ".csv";
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            requestAttributes.getResponse().setContentType("text/csv");
            requestAttributes.getResponse().setHeader("Content-Disposition", "attachment;fileName=" + filename);
            OutputStream os = requestAttributes.getResponse().getOutputStream();
            // os = hostService.exportHostAlarmCSV(hostQuery,os);
            os.flush();
            os.close();
            return new ResponseEntity(HttpStatus.OK);
        }catch(Exception e){
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * 异步全量导出
     * 调用此接口将文件异步下载到服务器上。
     * 此模块一个Session只允许一个报表下载。
     */
/*    @RequestMapping(value = "/download/downloadStart", method = RequestMethod.GET)
    public ResponseEntity<DownloadProcess> exportStart() throws IOException {
        String sessionId = MyRequestContext.getSessionContext().getId();
        DownloadProcess process = downloadingMap.get(sessionId);
        if (process != null && process.getCode() != 2) { //不为空则必须先下载，除非退出浏览器更换session
            return new ResponseEntity<>(process, HttpStatus.OK);
        }
        process = new DownloadProcess();
        downloadingMap.put(sessionId, process);
        try {
            String filePath = FilePathUtil.contractFilePath(sessionId, fileTempDir, ".zip");
            FileOutputStream os = new FileOutputStream(filePath);
            //开启线程
            exec.execute(new Thread(new HostDownloadAllReportThread(hostService, delta, os, process)));
        } catch (Exception e) {
            process.setCode(DownloadProcessCode.FAILED);
            return new ResponseEntity(process, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity(process, HttpStatus.OK);

    }


    *//**
     * 根据当前session，查询下载进度。
     *//*
    @RequestMapping(value = "/download/downloadStatus", method = RequestMethod.GET)
    public ResponseEntity<DownloadProcess> allExportProcess() {
        DownloadProcess process = downloadingMap.get(MyRequestContext.getSessionContext().getId());
        if (process == null) {
            process = new DownloadProcess();
            process.setCode(DownloadProcessCode.NULL); //不存在
        }
        return new ResponseEntity(process, HttpStatus.OK);
    }


    *//**
     * 根据当前session，下载报表。
     *//*
    @RequestMapping(value = "/download/downloadFile", method = RequestMethod.GET)
    public ResponseEntity<DownloadProcess> allExportDownload() throws IOException {
        String sessionID = MyRequestContext.getSessionContext().getId();
        DownloadProcess process = downloadingMap.get(sessionID);
        if (process == null) {
            process = new DownloadProcess();
            process.setCode(DownloadProcessCode.NULL);
            return new ResponseEntity(process, HttpStatus.OK);
        }
        if (process.getProcess() != 100) {
            return new ResponseEntity(process, HttpStatus.OK);
        }
        process = new DownloadProcess();
        OutputStream os = null;
        FileInputStream fis = null;
        try {
            String filename = "全部主机告警.csv";
            //解决中文乱码
            filename = new String(filename.getBytes(), "ISO-8859-1");
            //下载流
            MyRequestContext.getResponseContext().setHeader("Content-Disposition", "attachment;fileName=" + filename);
            File f = new File(FilePathUtil.contractFilePath(sessionID, fileTempDir, ".zip"));
            fis = new FileInputStream(f);
            os = MyRequestContext.getResponseContext().getOutputStream();
            byte[] b = new byte[2048];
            int ch;
            while ((ch = fis.read(b)) != -1) {
                os.write(b, 0, ch);
            }
            //删除临时文件和进度条
            f.delete();
            downloadingMap.remove(sessionID);
            process.setCode(DownloadProcessCode.SUCCESS);
        } catch (Exception e) {
            process.setCode(DownloadProcessCode.FAILED);
            return new ResponseEntity(process, HttpStatus.BAD_REQUEST);
        } finally {
            os.flush();
            fis.close();
            os.close();
        }
        return new ResponseEntity(process, HttpStatus.OK);
    }*/
}
