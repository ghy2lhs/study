package com.swad.base.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.elasticsearch.http.HttpStats;
import org.springframework.http.HttpStatus;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.ModelAndView;

public class CustomDispatcherServlet extends DispatcherServlet {

	
	private static final long serialVersionUID = 1L;

	@Override
	protected ModelAndView processHandlerException(HttpServletRequest request,HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		if (ex instanceof HttpRequestMethodNotSupportedException) {
			ModelAndView view = new ModelAndView();
//			view.addObject("resData", new JsonGeneralResponse(StatusCode.FAILURE,StatusCode.MSG_STATUS_FAILURE));
//			view.setViewName("/405");
			response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			return view;
		} 
		return super.processHandlerException(request, response, handler, ex);
	}
}
