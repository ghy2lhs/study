package com.swad.base.es;

import io.searchbox.client.JestClient;
import io.searchbox.client.JestResult;
import io.searchbox.indices.CreateIndex;
import io.searchbox.indices.DeleteIndex;
import io.searchbox.indices.mapping.GetMapping;
import io.searchbox.indices.mapping.PutMapping;
import org.springframework.stereotype.Component;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
@Component
public class ElasticSearchIndexServiceImpl implements IElasticSearchIndexService {

    private static JestClient client=  ESInit.getInstants();

    public boolean isIndexExists(String index_name) throws Exception {
        GetMapping getMapping = new GetMapping.Builder().addIndex(index_name).build();
        JestResult jr = client.execute(getMapping);
        return jr.isSucceeded();
    }

    public boolean createIndex(String index_name, String type_name, String mapping_statement) throws Exception {
        try {
            if(!isIndexExists(index_name)){
                JestResult jr = client.execute(new CreateIndex.Builder(index_name).build());
                if(jr.isSucceeded()){
                    if(createIndexMapping(index_name, type_name, mapping_statement)){
                        return true;
                    }
                    return false;
                };
                // failure to add a index,return false
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean createIndexMapping(String index_name, String type_name, String mapping_statement) throws Exception {
        PutMapping putMapping = new PutMapping.Builder(index_name, type_name, mapping_statement).build();
        JestResult jr = client.execute(putMapping);
        return jr.isSucceeded();
    }

    public String getIndexMapping(String index_name, String type_name) throws Exception {
        GetMapping getMapping = new GetMapping.Builder().addIndex(index_name).addType(type_name).build();
        JestResult jr = client.execute(getMapping);
        return jr.getJsonString();
    }

    public boolean deleteIndex(String index_name) throws Exception {
        JestResult jr = client.execute(new DeleteIndex.Builder(index_name).build());
        return jr.isSucceeded();
    }
}
