package com.swad.base.es;

import com.google.gson.JsonArray;
import com.swad.util.JsonRawString;
import io.searchbox.core.SearchResult;

import java.io.IOException;
import java.util.List;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
public interface IElasticSearchService {
    /**
     * 保存一个文档
     *
     * @param index_name
     * @param type_name
     * @param source
     * @return
     */
    boolean saveOneDoc(String index_name, String type_name, String source);

    /**
     * 保存多个文档
     *
     * @param index_name
     * @param type_name
     * @param query
     * @return
     */
    boolean saveMultiplyDoc(String index_name, String type_name, String query);

    /**
     * 根据id删除文档
     *
     * @param index_name
     * @param type_name
     * @param id
     * @return
     * @throws Exception
     */
    boolean delete(String index_name, String type_name, String id) throws Exception;

    /**
     * 修改文档
     *
     * @param index_name
     * @param type_name
     * @param query
     * @return
     * @throws IOException
     */
    boolean modify(String index_name, String type_name, String query) throws IOException;

    /**
     * 根据一个文档的id找到该文档的所有数据
     *
     * @param doc_id 文档id
     */
    SearchResult getADocumentByDocId(String index_name, String type_name, String doc_id);

    /**
     * 根据多个文档的id找到相应id的文档记录
     *
     * @param ids
     */
    void getMultiplyDocumentsByDocIds(String[] ids);

    /**
     * 根据查询语句得到查询的内容
     *
     * @param index_name      索引名字
     * @param type_name       类型名字
     * @param query_statement 查询语句
     */
    SearchResult getDocumentsByQueryStatment(String index_name, String type_name, String query_statement) throws ESQueryException;

    /**
     * 为指定的文档索引
     *
     * @param index_name 索引名字
     * @param type_name  类型名字
     * @param objs       该索引的文档对象
     * @return
     * @throws Exception
     */
    boolean indexDocuments(String index_name, String type_name, List<Object> objs) throws Exception;

    /**
     * 找打查询条件下的记录条数
     *
     * @param index_name
     * @param type_name
     * @param query
     * @return
     * @throws Exception
     */
    long count(String index_name, String type_name, String query);

    /**
     * 得到hits中的json转换为List对象
     *
     * @param sr
     * @return
     */
    List<JsonRawString> getHitsAsList(SearchResult sr);

    /**
     * 得到hits的信息转换为JsonArray
     *
     * @param sr
     * @return
     */
    JsonArray getHitsInfo(SearchResult sr);


    /**
     * 得到查询结果的hits条数
     *
     * @param sr
     * @return
     */
    Double getHitsCount(SearchResult sr);

    /**
     * 得到source信息
     *
     * @param sr
     * @return
     */
    List<JsonRawString> getSourceAsList(SearchResult sr);

}
