package com.swad.base.es;

import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.config.HttpClientConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
@Component
public class ESInit {

    @Value("${es_url}")
    private static String es_url;

    private static JestClient instants;

    /**
     * Maximum timeout in milliseconds while executing search statement
     */
    private static final int MAX_SEARCH_QUERY_TIMEOUT = 60 * 1000;

    public static JestClient getInstants() {
        if(instants!=null){
            return instants;
        }
        JestClientFactory factory = new JestClientFactory();
        factory.setHttpClientConfig(new HttpClientConfig
                .Builder(es_url)
                .readTimeout(MAX_SEARCH_QUERY_TIMEOUT)
                .multiThreaded(true)
                .build());
        return factory.getObject();
    }

}
