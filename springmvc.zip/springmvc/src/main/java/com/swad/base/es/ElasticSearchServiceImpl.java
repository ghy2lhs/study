package com.swad.base.es;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.swad.util.JsonRawString;
import io.searchbox.client.JestClient;
import io.searchbox.client.JestResult;
import io.searchbox.core.*;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.common.Nullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by gonghaiyu on 2017/4/18.
 */
@Component
public class ElasticSearchServiceImpl implements IElasticSearchService {

    private static JestClient client =  ESInit.getInstants();

    public boolean saveOneDoc(String index_name, String type_name, String query) {

        /*IndexResponse response = client.execute();
                .setSource(source).get();
        long successflag = response.getShardInfo().getSuccessful();
        if(successflag > 0){
            return true;
        }*/
        return false;
    }

    public boolean saveMultiplyDoc(String index_name, String type_name, String query) {

        return false;
    }

    public boolean delete(String index_name, String type_name, @Nullable String id) throws Exception {
        /*Delete.Builder builder = new Delete.Builder(id).index(index_name).type(type_name).refresh(true);
        JestResult result = client.execute(builder.build());
        if (result != null && !result.isSucceeded()) {
            throw new ESQueryException();
        }
        return result.isSucceeded();*/
        DocumentResult dr = client.execute(new Delete.Builder(id).index(index_name).type(type_name).build());
        return dr.isSucceeded();
    }

    public boolean modify(String index_name, String type_name, String query) throws IOException {
        return false;
    }

    public SearchResult getADocumentByDocId(String index_name,String type_name,String doc_id) {
        String query = createQueryStatementToGetADocByDocId(doc_id);
        Search search = new Search.Builder(query)
                .addIndex(index_name)
                .addType(type_name)
                .build();
        SearchResult result = null;
        try {
            result = client.execute(search);
        } catch (IOException e) {
            new ESQueryException();
        }
        return result;

    }

    private String createQueryStatementToGetADocByDocId(String doc_id) {
        if(StringUtils.isEmpty(doc_id)){
            doc_id = "";
        }
        JSONObject jsonObject = new JSONObject();
        /*jsonObject = new JSONObject().put("query",
                new JSONObject().element("bool",
                        new JSONObject().element("must",
                                new JSONObject().element("term",
                                        new JSONObject().element("_id",doc_id)))));*/
        return jsonObject.toString();
    }

    public void getMultiplyDocumentsByDocIds(String[] ids) {

    }

    public SearchResult getDocumentsByQueryStatment(String index_name, String type_name, String query_statement) throws ESQueryException {
        Search search = new Search
                .Builder(query_statement)
                .addIndex(index_name)
                .addType(type_name)
                .build();
        SearchResult result = null;
        try {
             result = client.execute(search);
        } catch (IOException e) {
            throw new ESQueryException();
        }
        return result;
    }

    public boolean indexDocuments(String index_name, String type_name, List<Object> objs) throws Exception {
        Bulk.Builder bulk = new Bulk.Builder().defaultIndex(index_name).defaultType(type_name);
        for (Object obj : objs) {
            Index index = new Index.Builder(obj).build();
            bulk.addAction(index);
        }
        BulkResult br = client.execute(bulk.build());
        return br.isSucceeded();
    }

    public long count(String index_name, String type_name, String query){
        Count count = new Count.Builder()
                .query(query)
                .addIndex(index_name)
                .addType(type_name)
                .build();
        CountResult result = null;
        try {
            result = client.execute(count);
        } catch (IOException e) {
            new ESQueryException();
        }
        return result.getCount().longValue();
    }

    public List<JsonRawString> getHitsAsList(SearchResult sr) {
        List<JsonRawString> ret = new ArrayList<JsonRawString>(sr.getTotal());
        JsonArray array = getHitsInfo(sr);
        Iterator<JsonElement> it = array.iterator();
        while (it.hasNext()) {
            ret.add(new JsonRawString(it.next().getAsJsonObject().toString()));
        }
        return ret;
    }

    public Double getHitsCount(SearchResult sr) {
        if (sr == null) {
            return 0.0;
        }
        JsonObject json = sr.getJsonObject();
        JsonArray array = json.getAsJsonObject("hits").getAsJsonArray("hits");
        return Double.valueOf(array.size());
    }

    public List<JsonRawString> getSourceAsList(SearchResult sr) {
        List<JsonRawString> ret = new ArrayList<JsonRawString>(sr.getTotal());
        JsonArray array = getHitsInfo(sr);
        Iterator<JsonElement> it = array.iterator();
        while (it.hasNext()) {
            ret.add(new JsonRawString(it.next().getAsJsonObject().getAsJsonObject("_source").toString()));
        }

        return ret;
    }

    public JsonArray getHitsInfo(SearchResult sr){
        if (sr == null) {
            return new JsonArray();
        }
        JsonObject json = sr.getJsonObject();
        JsonArray array = json.getAsJsonObject("hits").getAsJsonArray("hits");
        return array;
    }
}
